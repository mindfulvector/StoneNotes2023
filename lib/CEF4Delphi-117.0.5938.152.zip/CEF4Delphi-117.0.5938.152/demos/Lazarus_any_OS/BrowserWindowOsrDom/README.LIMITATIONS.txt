Keyboard support on MacOS is known to be incomplete. 
