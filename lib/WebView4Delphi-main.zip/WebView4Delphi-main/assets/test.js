function myAlertFunction() {
    alert("Hello! I am an alert box!!");
}

